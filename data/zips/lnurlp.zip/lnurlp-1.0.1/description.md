Create a static LNURLp or LNaddress people can use to pay.
